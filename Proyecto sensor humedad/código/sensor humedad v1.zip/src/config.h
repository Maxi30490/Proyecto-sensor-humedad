#pragma once

// TFT ILI9341 (SPI por hardware en UNO: MOSI=11, MISO=12, SCK=13)
#define TFT_DC_PIN 2
#define TFT_RST_PIN 3
#define TFT_CS_PIN 10

// Sensor de humedad capacitivo
#define SOIL_ADC_PIN A0

// Calibración para Arduino Uno (ADC 10-bit)
#define SOIL_DRY_ADC 614   // ~3.0V (aire / seco)
#define SOIL_WET_ADC 245   // ~1.2V (agua / húmedo)

// Intervalo de actualización
#define UPDATE_INTERVAL_MS 500UL

// Umbrales de estado (en %)
#define THRESHOLD_SECO_MAX 39
#define THRESHOLD_OPTIMO_MAX 70
