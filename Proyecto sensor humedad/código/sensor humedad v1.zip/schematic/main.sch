{
  "version": 1,
  "symbols": [
    {
      "id": "arduino_1",
      "type": "reg:arduino-uno",
      "ref": "U1",
      "x": 40,
      "y": 36,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "soil_1",
      "type": "reg:capacitive-soil-moisture-v12",
      "ref": "U2",
      "x": 81,
      "y": 32,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "tft_1",
      "type": "reg:ili9341-tft-2-8",
      "ref": "U3",
      "x": 81,
      "y": 62,
      "rotation": 0,
      "mirror": false
    }
  ],
  "wires": [
    {
      "id": "bbs_w_0",
      "points": [
        {
          "x": 34,
          "y": 25
        },
        {
          "x": 12,
          "y": 25
        },
        {
          "x": 12,
          "y": 66
        },
        {
          "x": 59,
          "y": 66
        },
        {
          "x": 59,
          "y": 64
        },
        {
          "x": 75,
          "y": 64
        }
      ],
      "net": "N_D2"
    },
    {
      "id": "bbs_w_1",
      "points": [
        {
          "x": 34,
          "y": 27
        },
        {
          "x": 15,
          "y": 27
        },
        {
          "x": 15,
          "y": 63
        },
        {
          "x": 56,
          "y": 63
        },
        {
          "x": 56,
          "y": 62
        },
        {
          "x": 75,
          "y": 62
        }
      ],
      "net": "N_D3"
    },
    {
      "id": "bbs_w_2",
      "points": [
        {
          "x": 34,
          "y": 41
        },
        {
          "x": 18,
          "y": 41
        },
        {
          "x": 18,
          "y": 60
        },
        {
          "x": 75,
          "y": 60
        }
      ],
      "net": "N_D10"
    },
    {
      "id": "bbs_w_3",
      "points": [
        {
          "x": 34,
          "y": 43
        },
        {
          "x": 21,
          "y": 43
        },
        {
          "x": 21,
          "y": 69
        },
        {
          "x": 62,
          "y": 69
        },
        {
          "x": 62,
          "y": 66
        },
        {
          "x": 75,
          "y": 66
        }
      ],
      "net": "N_D11"
    },
    {
      "id": "bbs_w_4",
      "points": [
        {
          "x": 34,
          "y": 45
        },
        {
          "x": 24,
          "y": 45
        },
        {
          "x": 24,
          "y": 12
        },
        {
          "x": 103,
          "y": 12
        },
        {
          "x": 103,
          "y": 58
        },
        {
          "x": 87,
          "y": 58
        }
      ],
      "net": "N_D12"
    },
    {
      "id": "bbs_w_5",
      "points": [
        {
          "x": 34,
          "y": 47
        },
        {
          "x": 24,
          "y": 47
        },
        {
          "x": 24,
          "y": 72
        },
        {
          "x": 65,
          "y": 72
        },
        {
          "x": 65,
          "y": 68
        },
        {
          "x": 75,
          "y": 68
        }
      ],
      "net": "N_D13"
    },
    {
      "id": "bbs_w_6",
      "points": [
        {
          "x": 46,
          "y": 21
        },
        {
          "x": 56,
          "y": 21
        },
        {
          "x": 56,
          "y": 19
        },
        {
          "x": 97,
          "y": 19
        },
        {
          "x": 97,
          "y": 32
        },
        {
          "x": 87,
          "y": 32
        }
      ],
      "net": "N_A0"
    },
    {
      "id": "bbs_w_7",
      "points": [
        {
          "x": 46,
          "y": 33
        },
        {
          "x": 75,
          "y": 33
        }
      ],
      "net": "V5"
    },
    {
      "id": "bbs_w_8",
      "points": [
        {
          "x": 46,
          "y": 33
        },
        {
          "x": 59,
          "y": 33
        },
        {
          "x": 59,
          "y": 56
        },
        {
          "x": 75,
          "y": 56
        }
      ],
      "net": "V5"
    },
    {
      "id": "bbs_w_9",
      "points": [
        {
          "x": 46,
          "y": 33
        },
        {
          "x": 59,
          "y": 33
        },
        {
          "x": 59,
          "y": 22
        },
        {
          "x": 100,
          "y": 22
        },
        {
          "x": 100,
          "y": 56
        },
        {
          "x": 87,
          "y": 56
        }
      ],
      "net": "V5"
    },
    {
      "id": "bbs_w_10",
      "points": [
        {
          "x": 46,
          "y": 39
        },
        {
          "x": 56,
          "y": 39
        },
        {
          "x": 56,
          "y": 31
        },
        {
          "x": 75,
          "y": 31
        }
      ],
      "net": "0"
    },
    {
      "id": "bbs_w_11",
      "points": [
        {
          "x": 46,
          "y": 39
        },
        {
          "x": 56,
          "y": 39
        },
        {
          "x": 56,
          "y": 58
        },
        {
          "x": 75,
          "y": 58
        }
      ],
      "net": "0"
    }
  ],
  "junctions": [
    {
      "id": "j_46_33",
      "x": 46,
      "y": 33
    },
    {
      "id": "j_59_33",
      "x": 59,
      "y": 33
    },
    {
      "id": "j_56_39",
      "x": 56,
      "y": 39
    }
  ],
  "netLabels": [
    {
      "id": "bbs_nl_0",
      "name": "N_D2",
      "x": 34,
      "y": 25,
      "owner": "arduino_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_1",
      "name": "N_D3",
      "x": 34,
      "y": 27,
      "owner": "arduino_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_2",
      "name": "N_D10",
      "x": 34,
      "y": 41,
      "owner": "arduino_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_3",
      "name": "N_D11",
      "x": 34,
      "y": 43,
      "owner": "arduino_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_4",
      "name": "N_D12",
      "x": 34,
      "y": 45,
      "owner": "arduino_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_5",
      "name": "N_D13",
      "x": 34,
      "y": 47,
      "owner": "arduino_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_6",
      "name": "N_A0",
      "x": 46,
      "y": 21,
      "owner": "arduino_1",
      "anchor": "start"
    },
    {
      "id": "bbs_nl_7",
      "name": "V5",
      "x": 46,
      "y": 33,
      "owner": "arduino_1",
      "anchor": "start"
    },
    {
      "id": "bbs_nl_8",
      "name": "GND",
      "x": 46,
      "y": 39,
      "owner": "arduino_1",
      "anchor": "start"
    }
  ],
  "probes": [],
  "directives": [],
  "breadboardSync": {
    "sourceHash": "13439:247150793",
    "symbolIds": [
      "arduino_1",
      "soil_1",
      "tft_1"
    ],
    "wireIds": [
      "bbs_w_0",
      "bbs_w_1",
      "bbs_w_2",
      "bbs_w_3",
      "bbs_w_4",
      "bbs_w_5",
      "bbs_w_6",
      "bbs_w_7",
      "bbs_w_8",
      "bbs_w_9",
      "bbs_w_10",
      "bbs_w_11"
    ],
    "netLabelIds": [
      "bbs_nl_0",
      "bbs_nl_1",
      "bbs_nl_2",
      "bbs_nl_3",
      "bbs_nl_4",
      "bbs_nl_5",
      "bbs_nl_6",
      "bbs_nl_7",
      "bbs_nl_8"
    ]
  }
}