# Detector de humedad de plantas con Arduino y TFT

Sistema de monitorización de humedad del suelo con visualización en pantalla táctil ILI9341 y salida de datos por puerto serie.

## What it does
Mide el nivel de humedad del suelo mediante un sensor capacitivo y lo presenta en una interfaz gráfica en una pantalla TFT de 2.8 pulgadas. El sistema clasifica el estado en tres categorías (Seco, Óptimo, Húmedo) con colores diferenciados y envía los datos crudos y calculados por consola serial.

## Hardware
- **Microcontrolador**: Arduino Uno
- **Sensor**: Capacitive Soil Moisture V1.2
- **Display**: ILI9341 TFT 2.8" (SPI)
- **Otros**: Protoboard (full breadboard)

## Wiring
Conexión mediante protoboard utilizando pines SPI estándar y analógico para el sensor.

| Componente | Pin | Arduino Uno |
| :--- | :--- | :--- |
| **TFT** | VCC | 5V |
| **TFT** | GND | GND |
| **TFT** | CS | D10 |
| **TFT** | DC | D2 |
| **TFT** | RESET | D3 |
| **TFT** | MOSI | D11 |
| **TFT** | MISO | D12 |
| **TFT** | SCK | D13 |
| **TFT** | LED | 5V |
| **Sensor** | VCC | 5V |
| **Sensor** | GND | GND |
| **Sensor** | AOUT | A0 |

## How to use
1. Conecta los componentes según la tabla de conexiones.
2. Sube el código a la placa Arduino Uno.
3. Abre el **Monitor Serial** a 115200 baudios para ver los datos de humedad y estado en tiempo real.
4. La pantalla TFT mostrará automáticamente el estado actual del suelo cada 500ms.

## Files
- `src/config.h`: Definiciones de pines, umbrales y calibración del ADC.
- `src/main.cpp`: Lógica principal de lectura, cálculo de porcentajes y renderizado en pantalla.
- `schematic/main.sch`: Esquemático del circuito.
- `wiring/wiring.json`: Descripción del cableado en formato JSON.
- `platformio.ini`: Configuración del entorno de desarrollo.