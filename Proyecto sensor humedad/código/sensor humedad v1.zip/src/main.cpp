#include <Arduino.h>
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ILI9341.h>
#include <math.h>

#include "config.h"

Adafruit_ILI9341 tft(TFT_CS_PIN, TFT_DC_PIN, TFT_RST_PIN);

enum EstadoHumedad {
  ESTADO_SECO,
  ESTADO_OPTIMO,
  ESTADO_HUMEDO
};

struct LecturaSuelo {
  int raw;
  int porcentaje;
  EstadoHumedad estado;
};

unsigned long lastUpdateMs = 0;

int calcularPorcentaje(int raw) {
  int porcentaje = (int)lroundf((float)(raw - SOIL_DRY_ADC) * 100.0f / (float)(SOIL_WET_ADC - SOIL_DRY_ADC));
  return constrain(porcentaje, 0, 100);
}

EstadoHumedad clasificarEstado(int porcentaje) {
  if (porcentaje <= THRESHOLD_SECO_MAX) return ESTADO_SECO;
  if (porcentaje <= THRESHOLD_OPTIMO_MAX) return ESTADO_OPTIMO;
  return ESTADO_HUMEDO;
}

const __FlashStringHelper* textoEstado(EstadoHumedad estado) {
  switch (estado) {
    case ESTADO_SECO:   return F("SECO");
    case ESTADO_OPTIMO: return F("OPTIMO");
    case ESTADO_HUMEDO: return F("HUMEDO");
    default:            return F("DESCONOCIDO");
  }
}

uint16_t colorFondoEstado(EstadoHumedad estado) {
  switch (estado) {
    case ESTADO_SECO:   return ILI9341_MAROON;
    case ESTADO_OPTIMO: return ILI9341_DARKGREEN;
    case ESTADO_HUMEDO: return ILI9341_NAVY;
    default:            return ILI9341_BLACK;
  }
}

LecturaSuelo leerSuelo() {
  LecturaSuelo l;
  l.raw = analogRead(SOIL_ADC_PIN);
  l.porcentaje = calcularPorcentaje(l.raw);
  l.estado = clasificarEstado(l.porcentaje);
  return l;
}

void mostrarEnTFT(const LecturaSuelo& lectura) {
  tft.fillScreen(colorFondoEstado(lectura.estado));

  tft.setTextColor(ILI9341_WHITE);
  tft.setTextWrap(false);

  tft.setTextSize(2);
  tft.setCursor(20, 20);
  tft.print(F("HUMEDAD SUELO"));

  tft.drawFastHLine(20, 45, 280, ILI9341_WHITE);

  tft.setTextSize(3);
  tft.setCursor(20, 80);
  tft.print(F("Valor: "));
  tft.print(lectura.porcentaje);
  tft.print(F("%"));

  tft.setTextSize(3);
  tft.setCursor(20, 140);
  tft.print(F("Estado:"));

  tft.setTextSize(4);
  tft.setCursor(20, 180);
  tft.print(textoEstado(lectura.estado));

  tft.setTextSize(2);
  tft.setCursor(20, 230);
  tft.print(F("ADC: "));
  tft.print(lectura.raw);
}

void enviarSerial(const LecturaSuelo& lectura) {
  Serial.print(F("Raw ADC: "));
  Serial.print(lectura.raw);
  Serial.print(F(" | Humedad: "));
  Serial.print(lectura.porcentaje);
  Serial.print(F("% | Estado: "));
  Serial.println(textoEstado(lectura.estado));
}

void setup() {
  Serial.begin(115200);

  tft.begin();
  tft.setRotation(1);
  tft.fillScreen(ILI9341_BLACK);
}

void loop() {
  unsigned long now = millis();
  if (now - lastUpdateMs >= UPDATE_INTERVAL_MS) {
    lastUpdateMs = now;

    LecturaSuelo lectura = leerSuelo();
    mostrarEnTFT(lectura);
    enviarSerial(lectura);
  }
}
